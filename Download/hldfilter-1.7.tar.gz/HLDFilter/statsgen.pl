#!/usr/bin/perl -w

###########################################################################
#      Copyright Dan Cardamore <wombat@hld.ca>
#      This program is licensed under the Gnu GPL.  Since this is free
#      software, the author assumes no liability for it and the damages
#      that it may cause.
#
#      Please read the README file.  For install instructions, please visit
#      http://www.hld.ca/opensource/hldfilter
#
###########################################################################
# 	$rcs = ' $Id: statsgen.pl,v 1.2 2000/12/26 17:40:25 wombat Exp $ ' ;
###########################################################################
use strict;
use Mail::Audit;    # this is for filtering mail
use Mail::Sender;   # this is for sending my gpg key
use Date::Manip;    # this is for logging the date
use Carp;
############################################################################

use vars (
					'%rc',
					'%stats',
					'%spamstats'
				 );

my $uid = $>;
my $home = (getpwuid ($uid))[7];
my $configDir = $home . "/.hldfilter";
my $logfile = $configDir . "/log";

sub error($)
{
	my $error = shift;
	$error = "ERROR: $error";
	confess ($error);
}

sub getConfig()
{
	open (RC, "<$configDir/hldfilter.rc") or &error($!);
	flock (RC, 2);
	while (<RC>)
	{
		chomp;
		s/#.*//;                # no comments
		s/^\s+//;               # no leading white
		s/\s+$//;               # no trailing white
		next unless length;     # anything left?
		my ($var, $value) = split(/\s*=\s*/, $_, 2);
		$rc{$var} = $value;
	}
	flock (*RC, 8);
	close(*RC);
	return 1;
}

sub collectStats()
{
		open (STATS, "<$rc{'statsdir'}/stats.dat") or error($!);
		flock (STATS, 2);
		my @statsdat = <STATS>;
		flock (STATS, 8);
		close (STATS);
		chomp @statsdat;

		foreach my $line (@statsdat)
		{
				my ($from, $date, $type) = split /~:~/,$line;
				if ($type eq "spam")
				{
						$spamstats{$from}++;
				}
				elsif ($type eq "normal")
				{
						$stats{$from}++;
				}
		}
}


sub writeStats()
{
		open (STATS, ">$rc{'statsdir'}/stats.shtml") or error($!);
		flock (STATS, 2);

		print STATS "<table border=2 width=100%>\n";
		print STATS "<tr><td bgcolor=#477979 colspan=2>Spammers Blocked</td></tr>\n";
		print STATS "<tr><td bgcolor=#477979>From</td><td bgcolor=#477979>Count</td></tr>\n";

		foreach my $from (keys %spamstats)
		{
				print STATS "<tr><td>$from</td><td>$spamstats{$from}</td></tr>\n";
		}
		print STATS "</table>\n";

		print STATS "<hr>\n";

		print STATS "<table border=2 width=100%>\n";
		print STATS "<tr><td bgcolor=#477979 colspan=2>Accepted Mail</td></tr>\n";
	  print STATS "<tr><td bgcolor=#477979>From</td><td bgcolor=#477979>Count</td></tr>\n";

		foreach my $from (keys %stats)
		{
				print STATS "<tr><td>$from</td><td>$stats{$from}</td></tr>\n";
		}
		print STATS "</table>\n";

		flock (STATS, 8);
		close (STATS);
}


###########
#  Start  #
###########

print "Reading config file\n";
getConfig();

print "Collecting stats\n";
collectStats();

print "Writing stats to html\n";
writeStats();
